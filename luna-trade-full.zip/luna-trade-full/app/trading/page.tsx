'use client';

import TradingTerminal from '@/components/TradingTerminal';
import Link from 'next/link';
import { signOut, useSession } from 'next-auth/react';

export default function TradingPage() {
  const { data: session } = useSession();

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Top Navigation */}
      <nav className="border-b border-[#2A2A2A] bg-[#0A0A0A]/95 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8972E]" />
            <div>
              <div className="font-semibold text-xl tracking-tight">LUNA TRADE</div>
              <div className="text-[10px] text-[#888] -mt-1">PREMIUM INVESTMENT PLATFORM</div>
            </div>
          </div>

          <div className="flex items-center gap-8 text-sm">
            <Link href="/trading" className="text-[#D4AF37] font-medium">Trading</Link>
            <Link href="/portfolio" className="hover:text-[#D4AF37] transition">Analytics</Link>
            <Link href="/funding" className="hover:text-[#D4AF37] transition">Funding</Link>
            <Link href="/investments-move" className="hover:text-[#D4AF37] transition">ACATS</Link>
            
            <div className="w-px h-4 bg-[#2A2A2A]" />

            {session?.user ? (
              <div className="flex items-center gap-4">
                <span className="text-sm text-[#888]">{session.user.email}</span>
                <button 
                  onClick={() => signOut({ callbackUrl: '/login' })}
                  className="text-xs px-4 py-1.5 rounded-full border border-[#2A2A2A] hover:bg-[#1A1A1A] transition"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link href="/login" className="text-sm">Login</Link>
            )}

            <div className="text-xs px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              Paper Trading
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-8 py-10">
        <div className="mb-8">
          <div className="flex items-end justify-between">
            <div>
              <h1 className="text-4xl font-semibold tracking-tighter">Live Trading</h1>
              <p className="text-[#888] mt-1">Real-time positions powered by Alpaca • Plaid funding enabled</p>
            </div>
            <Link 
              href="/funding" 
              className="px-6 py-2.5 rounded-2xl border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition text-sm font-medium"
            >
              Fund Account
            </Link>
          </div>
        </div>

        <TradingTerminal />
      </div>
    </div>
  );
}
