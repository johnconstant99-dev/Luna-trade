import { NextRequest, NextResponse } from 'next/server';

const ALPACA_BASE = process.env.ALPACA_ENV === 'live' ? 'https://api.alpaca.markets' : 'https://paper-api.alpaca.markets';
const headers = {
  'APCA-API-KEY-ID': process.env.ALPACA_API_KEY!,
  'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY!,
  'Content-Type': 'application/json',
};

export async function POST(request: NextRequest) {
  const order = await request.json();
  const res = await fetch(`${ALPACA_BASE}/v2/orders`, {
    method: 'POST',
    headers,
    body: JSON.stringify(order),
  });
  const data = await res.json();
  return NextResponse.json(data);
}
