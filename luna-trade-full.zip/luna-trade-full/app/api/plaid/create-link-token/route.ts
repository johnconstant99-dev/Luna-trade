import { NextRequest, NextResponse } from 'next/server';
import { Configuration, PlaidApi, PlaidEnvironments } from 'plaid';

const plaidClient = new PlaidApi(new Configuration({
  basePath: PlaidEnvironments[process.env.PLAID_ENV || 'sandbox'],
  baseOptions: {
    headers: {
      'PLAID-CLIENT-ID': process.env.PLAID_CLIENT_ID!,
      'PLAID-SECRET': process.env.PLAID_SECRET!,
    },
  },
}));

export async function POST(request: NextRequest) {
  const body = await request.json();

  const response = await plaidClient.linkTokenCreate({
    user: { client_user_id: 'user-' + Date.now() },
    client_name: 'Luna Trade',
    products: body.products || ['auth', 'investments_auth'],
    country_codes: ['US'],
    language: 'en',
    investments_auth: body.investments_auth,
  });

  return NextResponse.json({ link_token: response.data.link_token });
}
