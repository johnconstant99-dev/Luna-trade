'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { signOut, useSession } from 'next-auth/react';

interface Position {
  symbol: string;
  qty: number;
  market_value: number;
  unrealized_pl: number;
}

interface Account {
  portfolio_value: string;
  cash: string;
  buying_power: string;
  status: string;
}

export default function Dashboard() {
  const { data: session } = useSession();
  const [account, setAccount] = useState<Account | null>(null);
  const [positions, setPositions] = useState<Position[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [accountRes, positionsRes] = await Promise.all([
        fetch('/api/alpaca/account'),
        fetch('/api/alpaca/positions'),
      ]);

      if (accountRes.ok) setAccount(await accountRes.json());
      if (positionsRes.ok) setPositions(await positionsRes.json());
    } catch (error) {
      console.error('Failed to fetch dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const totalValue = account ? parseFloat(account.portfolio_value) : 0;
  const totalPL = positions.reduce((sum, p) => sum + parseFloat(p.unrealized_pl as any), 0);
  const totalPositions = positions.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="text-[#888]">Loading your dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Top Navigation */}
      <nav className="border-b border-[#2A2A2A] bg-[#0A0A0A]/95 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8972E]" />
            <div>
              <div className="font-semibold text-xl tracking-tight">LUNA TRADE</div>
              <div className="text-[10px] text-[#888] -mt-1">DASHBOARD</div>
            </div>
          </div>

          <div className="flex items-center gap-8 text-sm">
            <Link href="/dashboard" className="text-[#D4AF37] font-medium">Dashboard</Link>
            <Link href="/trading" className="hover:text-[#D4AF37] transition">Trading</Link>
            <Link href="/portfolio" className="hover:text-[#D4AF37] transition">Analytics</Link>
            <Link href="/funding" className="hover:text-[#D4AF37] transition">Funding</Link>

            {session?.user && (
              <div className="flex items-center gap-4">
                <span className="text-sm text-[#888]">{session.user.email}</span>
                <button 
                  onClick={() => signOut({ callbackUrl: '/login' })}
                  className="text-xs px-4 py-1.5 rounded-full border border-[#2A2A2A] hover:bg-[#1A1A1A] transition"
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-8 py-10">
        {/* Welcome Header */}
        <div className="mb-10">
          <h1 className="text-5xl font-semibold tracking-tighter">
            Welcome back{session?.user?.name ? `, ${session.user.name.split(' ')[0]}` : ''}
          </h1>
          <p className="text-[#888] mt-2 text-lg">Here's what's happening with your portfolio today.</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-[1px] mb-1">PORTFOLIO VALUE</div>
            <div className="text-4xl font-semibold tracking-tighter mt-2">
              ${totalValue.toLocaleString()}
            </div>
            <div className={`text-sm mt-2 ${totalPL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {totalPL >= 0 ? '+' : ''}${totalPL.toFixed(2)} today
            </div>
          </div>

          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-[1px] mb-1">UNREALIZED P&amp;L</div>
            <div className={`text-4xl font-semibold tracking-tighter mt-2 ${totalPL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {totalPL >= 0 ? '+' : ''}${totalPL.toFixed(2)}
            </div>
            <div className="text-sm mt-2 text-[#888]">Across {totalPositions} positions</div>
          </div>

          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-[1px] mb-1">CASH AVAILABLE</div>
            <div className="text-4xl font-semibold tracking-tighter mt-2">
              ${account ? parseFloat(account.cash).toLocaleString() : '0'}
            </div>
            <div className="text-sm mt-2 text-[#888]">Ready to invest</div>
          </div>

          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-[1px] mb-1">BUYING POWER</div>
            <div className="text-4xl font-semibold tracking-tighter mt-2">
              ${account ? parseFloat(account.buying_power).toLocaleString() : '0'}
            </div>
            <div className="text-sm mt-2 text-emerald-400">Account: {account?.status || 'Active'}</div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-10">
          <h2 className="text-xl font-semibold mb-4 tracking-tight">Quick Actions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link href="/trading" className="card p-6 rounded-3xl hover:border-[#D4AF37] transition group">
              <div className="font-semibold text-lg group-hover:text-[#D4AF37]">Start Trading</div>
              <div className="text-sm text-[#888] mt-1">Place orders on Alpaca</div>
            </Link>
            <Link href="/portfolio" className="card p-6 rounded-3xl hover:border-[#D4AF37] transition group">
              <div className="font-semibold text-lg group-hover:text-[#D4AF37]">View Analytics</div>
              <div className="text-sm text-[#888] mt-1">Deep portfolio insights</div>
            </Link>
            <Link href="/funding" className="card p-6 rounded-3xl hover:border-[#D4AF37] transition group">
              <div className="font-semibold text-lg group-hover:text-[#D4AF37]">Fund Account</div>
              <div className="text-sm text-[#888] mt-1">Connect bank via Plaid</div>
            </Link>
            <Link href="/investments-move" className="card p-6 rounded-3xl hover:border-[#D4AF37] transition group">
              <div className="font-semibold text-lg group-hover:text-[#D4AF37]">ACATS Transfer</div>
              <div className="text-sm text-[#888] mt-1">Move positions from another broker</div>
            </Link>
          </div>
        </div>

        {/* Top Holdings Preview */}
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold tracking-tight">Top Holdings</h2>
            <Link href="/portfolio" className="text-sm text-[#D4AF37] hover:underline">View Full Analytics →</Link>
          </div>

          <div className="card rounded-3xl overflow-hidden">
            {positions.length > 0 ? (
              <table className="w-full text-sm">
                <thead className="bg-[#0F0F0F] text-xs text-[#888] uppercase tracking-wider">
                  <tr>
                    <th className="px-8 py-4 text-left">Symbol</th>
                    <th className="px-8 py-4 text-right">Shares</th>
                    <th className="px-8 py-4 text-right">Market Value</th>
                    <th className="px-8 py-4 text-right">P&amp;L</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2A2A2A]">
                  {positions
                    .sort((a, b) => parseFloat(b.market_value as any) - parseFloat(a.market_value as any))
                    .slice(0, 5)
                    .map((pos, index) => {
                      const pl = parseFloat(pos.unrealized_pl as any);
                      return (
                        <tr key={index} className="hover:bg-[#111]">
                          <td className="px-8 py-5 font-medium text-[#D4AF37]">{pos.symbol}</td>
                          <td className="px-8 py-5 text-right font-mono">{pos.qty}</td>
                          <td className="px-8 py-5 text-right font-mono">${parseFloat(pos.market_value as any).toFixed(2)}</td>
                          <td className={`px-8 py-5 text-right font-mono ${pl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                            {pl >= 0 ? '+' : ''}${pl.toFixed(2)}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            ) : (
              <div className="px-8 py-12 text-center text-[#666]">
                No positions yet. Start trading to see your holdings here.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
