'use client';

import { useState } from 'react';

export default function InvestmentsMovePage() {
  const [loading, setLoading] = useState(false);
  const [transferData, setTransferData] = useState<any>(null);

  const startInvestmentsMove = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/plaid/create-link-token', {
        method: 'POST',
        body: JSON.stringify({
          products: ['investments_auth'],
          investments_auth: {
            masked_number_match_enabled: true,
            stated_account_number_enabled: true
          }
        })
      });
      const { link_token } = await res.json();

      const handler = (window as any).Plaid.create({
        token: link_token,
        onSuccess: async (public_token: string) => {
          const exchangeRes = await fetch('/api/plaid/exchange-public-token', {
            method: 'POST',
            body: JSON.stringify({ public_token })
          });
          const { access_token } = await exchangeRes.json();

          // Get Investments Auth data
          const investmentsRes = await fetch('/api/plaid/investments-auth-get', {
            method: 'POST',
            body: JSON.stringify({ access_token })
          });
          const data = await investmentsRes.json();
          setTransferData(data);
        }
      });
      handler.open();
    } catch (e) {
      alert('Failed to start Investments Move');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-8 py-16">
      <h1 className="text-4xl font-semibold tracking-tight mb-3">Investments Move</h1>
      <p className="text-[#888] mb-10">Automate ACATS transfers using broker-sourced data from Plaid.</p>

      {!transferData ? (
        <button 
          onClick={startInvestmentsMove} 
          disabled={loading}
          className="btn-gold px-10 py-4 rounded-2xl text-lg"
        >
          {loading ? 'Connecting to Broker...' : 'Connect Broker Account via Plaid'}
        </button>
      ) : (
        <div className="card p-8 rounded-3xl">
          <h3 className="text-xl mb-6">Transfer Data Retrieved</h3>
          <pre className="bg-black p-6 rounded-2xl text-sm overflow-auto">
            {JSON.stringify(transferData, null, 2)}
          </pre>
          <button className="mt-6 btn-gold px-8 py-3 rounded-2xl">Submit ACATS Transfer</button>
        </div>
      )}
    </div>
  );
}
