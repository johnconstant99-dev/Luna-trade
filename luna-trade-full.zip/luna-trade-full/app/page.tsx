import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
      <div className="text-center max-w-lg px-8">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#B8972E]" />
        </div>
        <h1 className="text-6xl font-semibold tracking-tighter mb-4">Luna Trade</h1>
        <p className="text-xl text-[#888] mb-10">Professional investment platform.<br />Live trading • Secure funding • ACATS transfers.</p>

        <div className="flex flex-col gap-3">
          <Link href="/login" className="btn-gold py-4 rounded-2xl text-lg">Sign In to Start Trading</Link>
          <Link href="/signup" className="py-4 rounded-2xl border border-[#2A2A2A] hover:bg-[#111] transition">Create Free Account</Link>
        </div>

        <p className="mt-12 text-xs text-[#555]">Demo credentials: demo@lunatrade.com / demo123</p>
      </div>
    </div>
  );
}
