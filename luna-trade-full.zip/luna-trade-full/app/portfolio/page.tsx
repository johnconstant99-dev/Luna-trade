'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { signOut, useSession } from 'next-auth/react';

interface Position {
  symbol: string;
  qty: number;
  avg_entry_price: number;
  current_price: number;
  market_value: number;
  unrealized_pl: number;
  unrealized_plpc: number;
}

interface Account {
  portfolio_value: string;
  cash: string;
  buying_power: string;
}

export default function PortfolioAnalytics() {
  const { data: session } = useSession();
  const [positions, setPositions] = useState<Position[]>([]);
  const [account, setAccount] = useState<Account | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [accountRes, positionsRes] = await Promise.all([
        fetch('/api/alpaca/account'),
        fetch('/api/alpaca/positions'),
      ]);

      if (accountRes.ok) setAccount(await accountRes.json());
      if (positionsRes.ok) setPositions(await positionsRes.json());
    } catch (error) {
      console.error('Failed to fetch data', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  // Calculations
  const totalValue = account ? parseFloat(account.portfolio_value) : 0;
  const totalCash = account ? parseFloat(account.cash) : 0;
  const totalPL = positions.reduce((sum, p) => sum + parseFloat(p.unrealized_pl as any), 0);
  const totalPLPercent = totalValue > 0 ? (totalPL / (totalValue - totalPL)) * 100 : 0;

  // Asset Allocation
  const totalInvested = positions.reduce((sum, p) => sum + parseFloat(p.market_value as any), 0);
  const allocation = positions.map(pos => ({
    ...pos,
    percentage: totalInvested > 0 ? (parseFloat(pos.market_value as any) / totalInvested) * 100 : 0,
  }));

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="text-[#888]">Loading portfolio analytics...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Navigation */}
      <nav className="border-b border-[#2A2A2A] bg-[#0A0A0A]/95 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8972E]" />
            <div>
              <div className="font-semibold text-xl tracking-tight">LUNA TRADE</div>
              <div className="text-[10px] text-[#888] -mt-1">PORTFOLIO ANALYTICS</div>
            </div>
          </div>

          <div className="flex items-center gap-8 text-sm">
            <Link href="/trading" className="hover:text-[#D4AF37] transition">Trading</Link>
            <Link href="/portfolio" className="text-[#D4AF37] font-medium">Analytics</Link>
            <Link href="/funding" className="hover:text-[#D4AF37] transition">Funding</Link>
            
            {session?.user && (
              <button 
                onClick={() => signOut({ callbackUrl: '/login' })}
                className="text-xs px-4 py-1.5 rounded-full border border-[#2A2A2A] hover:bg-[#1A1A1A]"
              >
                Logout
              </button>
            )}
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-8 py-10">
        <div className="mb-10">
          <h1 className="text-5xl font-semibold tracking-tighter">Portfolio Analytics</h1>
          <p className="text-[#888] mt-2">Real-time insights into your investment performance</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-10">
          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-wider mb-1">TOTAL PORTFOLIO VALUE</div>
            <div className="text-4xl font-semibold tracking-tighter mt-2">
              ${totalValue.toLocaleString()}
            </div>
            <div className="text-emerald-400 text-sm mt-1">+${totalPL.toFixed(2)} today</div>
          </div>

          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-wider mb-1">UNREALIZED P&amp;L</div>
            <div className={`text-4xl font-semibold tracking-tighter mt-2 ${totalPL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {totalPL >= 0 ? '+' : ''}${totalPL.toFixed(2)}
            </div>
            <div className="text-sm mt-1 text-[#888]">
              {totalPLPercent >= 0 ? '+' : ''}{totalPLPercent.toFixed(2)}% return
            </div>
          </div>

          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-wider mb-1">CASH AVAILABLE</div>
            <div className="text-4xl font-semibold tracking-tighter mt-2">
              ${totalCash.toLocaleString()}
            </div>
            <div className="text-sm mt-1 text-[#888]">Ready to deploy</div>
          </div>

          <div className="card p-6 rounded-3xl">
            <div className="text-xs text-[#888] tracking-wider mb-1">OPEN POSITIONS</div>
            <div className="text-4xl font-semibold tracking-tighter mt-2">{positions.length}</div>
            <div className="text-sm mt-1 text-[#888]">Across {positions.length} assets</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Asset Allocation */}
          <div className="lg:col-span-3 card rounded-3xl p-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <div className="font-semibold text-xl">Asset Allocation</div>
                <div className="text-sm text-[#888]">Current portfolio breakdown</div>
              </div>
              <div className="text-xs px-3 py-1 rounded-full bg-[#1A1A1A] border border-[#2A2A2A]">
                {positions.length} Holdings
              </div>
            </div>

            {allocation.length > 0 ? (
              <div className="space-y-5">
                {allocation
                  .sort((a, b) => b.percentage - a.percentage)
                  .map((item, index) => (
                    <div key={index}>
                      <div className="flex justify-between text-sm mb-2">
                        <div className="font-medium text-[#D4AF37]">{item.symbol}</div>
                        <div className="text-[#888]">
                          {item.percentage.toFixed(1)}% • ${parseFloat(item.market_value as any).toFixed(0)}
                        </div>
                      </div>
                      <div className="h-2.5 bg-[#1A1A1A] rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-[#D4AF37] to-[#B8972E] rounded-full transition-all"
                          style={{ width: `${Math.min(item.percentage, 100)}%` }}
                        />
                      </div>
                    </div>
                  ))}
              </div>
            ) : (
              <div className="text-center py-12 text-[#666]">No positions yet. Start trading to see allocation.</div>
            )}
          </div>

          {/* Performance Summary */}
          <div className="lg:col-span-2 card rounded-3xl p-8">
            <div className="font-semibold text-xl mb-6">Performance Summary</div>
            
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b border-[#2A2A2A] pb-4">
                <div className="text-[#888]">Total Invested</div>
                <div className="font-mono text-lg">${totalInvested.toFixed(2)}</div>
              </div>
              
              <div className="flex justify-between items-center border-b border-[#2A2A2A] pb-4">
                <div className="text-[#888]">Current Value</div>
                <div className="font-mono text-lg">${totalValue.toFixed(2)}</div>
              </div>

              <div className="flex justify-between items-center pt-2">
                <div className="font-medium">Net P&amp;L</div>
                <div className={`font-mono text-xl font-semibold ${totalPL >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {totalPL >= 0 ? '+' : ''}${totalPL.toFixed(2)}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#2A2A2A] text-xs text-[#666]">
              Data refreshed from Alpaca • Last update: just now
            </div>
          </div>
        </div>

        {/* Top Holdings Table */}
        <div className="mt-8 card rounded-3xl overflow-hidden">
          <div className="px-8 py-5 border-b border-[#2A2A2A] flex justify-between items-center">
            <div className="font-semibold">Top Holdings</div>
            <Link href="/trading" className="text-xs text-[#D4AF37] hover:underline">Manage Positions →</Link>
          </div>

          <table className="w-full text-sm">
            <thead className="bg-[#0F0F0F] text-xs text-[#888] uppercase tracking-wider">
              <tr>
                <th className="px-8 py-4 text-left">Symbol</th>
                <th className="px-8 py-4 text-right">Shares</th>
                <th className="px-8 py-4 text-right">Avg Cost</th>
                <th className="px-8 py-4 text-right">Current Price</th>
                <th className="px-8 py-4 text-right">Market Value</th>
                <th className="px-8 py-4 text-right">Unrealized P&amp;L</th>
                <th className="px-8 py-4 text-right">% of Portfolio</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A2A2A]">
              {positions.length > 0 ? (
                positions
                  .sort((a, b) => parseFloat(b.market_value as any) - parseFloat(a.market_value as any))
                  .map((pos, index) => {
                    const pl = parseFloat(pos.unrealized_pl as any);
                    const allocPercent = totalInvested > 0 ? (parseFloat(pos.market_value as any) / totalInvested) * 100 : 0;
                    
                    return (
                      <tr key={index} className="hover:bg-[#111]">
                        <td className="px-8 py-5 font-medium text-[#D4AF37]">{pos.symbol}</td>
                        <td className="px-8 py-5 text-right font-mono">{pos.qty}</td>
                        <td className="px-8 py-5 text-right font-mono">${parseFloat(pos.avg_entry_price as any).toFixed(2)}</td>
                        <td className="px-8 py-5 text-right font-mono">${parseFloat(pos.current_price as any).toFixed(2)}</td>
                        <td className="px-8 py-5 text-right font-mono">${parseFloat(pos.market_value as any).toFixed(2)}</td>
                        <td className={`px-8 py-5 text-right font-mono ${pl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {pl >= 0 ? '+' : ''}${pl.toFixed(2)}
                        </td>
                        <td className="px-8 py-5 text-right font-mono text-[#888]">
                          {allocPercent.toFixed(1)}%
                        </td>
                      </tr>
                    );
                  })
              ) : (
                <tr>
                  <td colSpan={7} className="px-8 py-12 text-center text-[#666]">
                    No positions found. Start trading to build your portfolio.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
