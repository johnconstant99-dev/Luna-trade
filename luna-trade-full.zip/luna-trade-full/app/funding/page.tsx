'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function FundingPage() {
  const [plaidLoading, setPlaidLoading] = useState(false);

  const startPlaidLink = async () => {
    setPlaidLoading(true);
    
    try {
      // Call our secure backend
      const res = await fetch('/api/plaid/create-link-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          products: ['auth', 'investments_auth'],
          investments_auth: {
            masked_number_match_enabled: true,
            stated_account_number_enabled: true,
            manual_entry_enabled: true
          }
        })
      });

      const { link_token } = await res.json();

      // Initialize Plaid Link
      const handler = (window as any).Plaid.create({
        token: link_token,
        onSuccess: async (public_token: string) => {
          // Exchange token on backend
          await fetch('/api/plaid/exchange-public-token', {
            method: 'POST',
            body: JSON.stringify({ public_token })
          });
          
          alert('Bank account linked successfully! You can now fund your account.');
        },
        onExit: () => setPlaidLoading(false)
      });

      handler.open();
    } catch (error) {
      alert('Failed to start Plaid Link');
      setPlaidLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <nav className="border-b border-[#2A2A2A] px-8 h-20 flex items-center">
        <Link href="/trading" className="text-[#D4AF37] hover:underline">← Back to Trading</Link>
      </nav>

      <div className="max-w-4xl mx-auto px-8 py-16">
        <h1 className="text-5xl font-semibold tracking-tighter mb-4">Fund Your Account</h1>
        <p className="text-xl text-[#888] mb-12">Connect your bank or transfer investments via ACATS</p>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Plaid Bank Linking */}
          <div className="card p-8 rounded-3xl">
            <div className="text-sm uppercase tracking-[2px] text-[#D4AF37] mb-3">INSTANT FUNDING</div>
            <h3 className="text-2xl font-semibold mb-4">Link Bank Account</h3>
            <p className="text-[#888] mb-8">Securely connect your bank using Plaid. Supports instant verification in many cases.</p>
            
            <button 
              onClick={startPlaidLink}
              disabled={plaidLoading}
              className="btn-gold w-full py-4 rounded-2xl text-lg disabled:opacity-70"
            >
              {plaidLoading ? 'Connecting...' : 'Connect Bank with Plaid'}
            </button>
          </div>

          {/* Investments Move / ACATS */}
          <div className="card p-8 rounded-3xl border border-[#D4AF37]/30">
            <div className="text-sm uppercase tracking-[2px] text-[#D4AF37] mb-3">BROKER TRANSFER</div>
            <h3 className="text-2xl font-semibold mb-4">Investments Move (ACATS)</h3>
            <p className="text-[#888] mb-8">Transfer your existing investments from another broker. Reduces rejections with broker-sourced data.</p>
            
            <Link 
              href="/investments-move"
              className="block text-center w-full py-4 rounded-2xl border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black transition font-medium"
            >
              Start ACATS Transfer
            </Link>
          </div>
        </div>

        <div className="mt-12 text-center text-xs text-[#666]">
          All transfers are secured with bank-level encryption. Plaid is SOC 2 Type II certified.
        </div>
      </div>
    </div>
  );
}
