'use client';

import React, { useState, useEffect } from 'react';

interface Position {
  symbol: string;
  qty: number;
  avg_entry_price: number;
  current_price: number;
  market_value: number;
  unrealized_pl: number;
  unrealized_plpc: number;
}

interface Account {
  buying_power: string;
  cash: string;
  portfolio_value: string;
  status: string;
}

export default function TradingTerminal() {
  const [positions, setPositions] = useState<Position[]>([]);
  const [account, setAccount] = useState<Account | null>(null);
  const [loading, setLoading] = useState(true);
  const [orderSymbol, setOrderSymbol] = useState('');
  const [orderQty, setOrderQty] = useState('');
  const [orderSide, setOrderSide] = useState<'buy' | 'sell'>('buy');
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [limitPrice, setLimitPrice] = useState('');

  const fetchData = async () => {
    try {
      const [accountRes, positionsRes] = await Promise.all([
        fetch('/api/alpaca/account'),
        fetch('/api/alpaca/positions'),
      ]);

      if (accountRes.ok) setAccount(await accountRes.json());
      if (positionsRes.ok) setPositions(await positionsRes.json());
    } catch (error) {
      console.error('Failed to fetch Alpaca data', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 15000);
    return () => clearInterval(interval);
  }, []);

  const placeOrder = async () => {
    if (!orderSymbol || !orderQty) return alert('Please enter symbol and quantity');

    const orderBody: any = {
      symbol: orderSymbol.toUpperCase(),
      qty: parseFloat(orderQty),
      side: orderSide,
      type: orderType,
      time_in_force: 'day',
    };

    if (orderType === 'limit' && limitPrice) {
      orderBody.limit_price = parseFloat(limitPrice);
    }

    try {
      const res = await fetch('/api/alpaca/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderBody),
      });

      if (res.ok) {
        alert(`Order placed successfully!`);
        setOrderSymbol('');
        setOrderQty('');
        setLimitPrice('');
        fetchData();
      } else {
        const error = await res.json();
        alert(`Order failed: ${error.error}`);
      }
    } catch (err) {
      alert('Failed to place order');
    }
  };

  if (loading) return <div className="p-8 text-center text-[#888]">Loading live trading data from Alpaca...</div>;

  return (
    <div className="space-y-8">
      {/* Account Summary */}
      {account && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="card p-5 rounded-2xl">
            <div className="text-xs text-[#888] mb-1">PORTFOLIO VALUE</div>
            <div className="text-3xl font-semibold tracking-tighter">${parseFloat(account.portfolio_value).toLocaleString()}</div>
          </div>
          <div className="card p-5 rounded-2xl">
            <div className="text-xs text-[#888] mb-1">BUYING POWER</div>
            <div className="text-3xl font-semibold tracking-tighter text-emerald-400">${parseFloat(account.buying_power).toLocaleString()}</div>
          </div>
          <div className="card p-5 rounded-2xl">
            <div className="text-xs text-[#888] mb-1">CASH</div>
            <div className="text-3xl font-semibold tracking-tighter">${parseFloat(account.cash).toLocaleString()}</div>
          </div>
          <div className="card p-5 rounded-2xl">
            <div className="text-xs text-[#888] mb-1">ACCOUNT STATUS</div>
            <div className="text-3xl font-semibold tracking-tighter capitalize text-emerald-400">{account.status}</div>
          </div>
        </div>
      )}

      {/* Live Positions */}
      <div className="card rounded-3xl overflow-hidden">
        <div className="px-8 py-5 border-b border-[#2A2A2A] flex justify-between items-center">
          <div className="font-semibold">Live Positions</div>
          <button onClick={fetchData} className="text-xs px-4 py-1.5 rounded-full border border-[#2A2A2A] hover:bg-[#1A1A1A]">Refresh</button>
        </div>

        <table className="w-full text-sm">
          <thead className="table-header">
            <tr>
              <th className="px-8 py-4 text-left font-normal">Symbol</th>
              <th className="px-8 py-4 text-right font-normal">Qty</th>
              <th className="px-8 py-4 text-right font-normal">Avg Entry</th>
              <th className="px-8 py-4 text-right font-normal">Current</th>
              <th className="px-8 py-4 text-right font-normal">Market Value</th>
              <th className="px-8 py-4 text-right font-normal">Unrealized P&amp;L</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#2A2A2A]">
            {positions.length > 0 ? positions.map((pos, i) => {
              const pl = parseFloat(pos.unrealized_pl as any);
              return (
                <tr key={i} className="hover:bg-[#111]">
                  <td className="px-8 py-5 font-medium text-[#D4AF37]">{pos.symbol}</td>
                  <td className="px-8 py-5 text-right font-mono">{pos.qty}</td>
                  <td className="px-8 py-5 text-right font-mono">${parseFloat(pos.avg_entry_price as any).toFixed(2)}</td>
                  <td className="px-8 py-5 text-right font-mono">${parseFloat(pos.current_price as any).toFixed(2)}</td>
                  <td className="px-8 py-5 text-right font-mono">${parseFloat(pos.market_value as any).toFixed(2)}</td>
                  <td className={`px-8 py-5 text-right font-mono ${pl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {pl >= 0 ? '+' : ''}${pl.toFixed(2)}
                  </td>
                </tr>
              );
            }) : (
              <tr><td colSpan={6} className="px-8 py-12 text-center text-[#666]">No open positions</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Order Entry */}
      <div className="card p-8 rounded-3xl">
        <div className="font-semibold mb-6 text-lg">Place Order</div>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <input value={orderSymbol} onChange={e => setOrderSymbol(e.target.value.toUpperCase())} placeholder="Symbol (AAPL)" className="bg-[#0A0A0A] border border-[#2A2A2A] rounded-2xl px-5 py-3" />
          <input value={orderQty} onChange={e => setOrderQty(e.target.value)} placeholder="Quantity" type="number" className="bg-[#0A0A0A] border border-[#2A2A2A] rounded-2xl px-5 py-3" />
          
          <select value={orderSide} onChange={e => setOrderSide(e.target.value as any)} className="bg-[#0A0A0A] border border-[#2A2A2A] rounded-2xl px-5 py-3">
            <option value="buy">Buy</option>
            <option value="sell">Sell</option>
          </select>
          
          <select value={orderType} onChange={e => setOrderType(e.target.value as any)} className="bg-[#0A0A0A] border border-[#2A2A2A] rounded-2xl px-5 py-3">
            <option value="market">Market</option>
            <option value="limit">Limit</option>
          </select>

          {orderType === 'limit' && (
            <input value={limitPrice} onChange={e => setLimitPrice(e.target.value)} placeholder="Limit Price" className="bg-[#0A0A0A] border border-[#2A2A2A] rounded-2xl px-5 py-3" />
          )}
        </div>

        <button onClick={placeOrder} className="mt-6 w-full btn-gold py-4 rounded-2xl text-lg">
          Place {orderSide.toUpperCase()} {orderType.toUpperCase()} Order
        </button>
      </div>
    </div>
  );
}
